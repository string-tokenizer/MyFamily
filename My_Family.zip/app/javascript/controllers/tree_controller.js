import { Controller } from "@hotwired/stimulus"

const initials = name => name.split(" ").slice(0, 2).map(w => w[0]).join("")

const avatar = p => {
  const inner = p.photo ? `<img src="${p.photo}" alt="">` : initials(p.name)
  return `<div class="avatar ${p.gender}">${inner}</div>`
}

export default class extends Controller {
  static targets = ["root", "canvas"]
  static values = { url: String }

  async connect() {
    try {
      const res = await fetch(this.urlValue)
      if (!res.ok) throw new Error(`Could not load ${this.urlValue} (HTTP ${res.status})`)
      this.people = (await res.json()).people
      this.byId = Object.fromEntries(this.people.map(p => [p.id, p]))
      this.people
        .filter(p => !p.isInLaw)
        .forEach(p => this.rootTarget.add(new Option(p.name, p.id)))
      this.render()
    } catch (error) {
      console.error(error)
      this.canvasTarget.innerHTML = `<p class="muted">⚠️ ${error.message}</p>`
    }
  }

  render() {
    const selected = this.rootTarget.value
    const roots = selected
      ? [this.byId[selected]]
      : this.people.filter(p => !p.fatherId && !p.motherId && !p.isInLaw)
    this.canvasTarget.innerHTML = `<ul>${roots.map(p => this.unit(p)).join("")}</ul>`
  }

  unit(p) {
    const spouses = p.spouses.map(s => this.byId[s.id]).filter(Boolean)
    const kids = this.people.filter(c => c.fatherId === p.id || c.motherId === p.id)
    const spouseHtml = spouses.map(s => `<span class="link">♥</span>${this.node(s)}`).join("")
    const kidsHtml = kids.length ? `<ul>${kids.map(k => this.unit(k)).join("")}</ul>` : ""
    return `<li><div class="unit">${this.node(p)}${spouseHtml}</div>${kidsHtml}</li>`
  }

  node(p) {
    const years = `${p.dob?.slice(0, 4) || "?"}${p.dateOfDeath ? " – " + p.dateOfDeath.slice(0, 4) : ""}`
    return `<a class="node ${p.gender} ${p.dateOfDeath ? "deceased" : ""}" href="/people/${p.id}">
      ${avatar(p)}
      <span class="node-name">${p.name}</span>
      <small>${years}</small>
    </a>`
  }
}