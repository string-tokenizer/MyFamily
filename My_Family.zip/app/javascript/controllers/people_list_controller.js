import { Controller } from "@hotwired/stimulus"

const initials = name => name.split(" ").slice(0, 2).map(w => w[0]).join("")
const avatar = p => `<div class="avatar ${p.gender}">${
  p.photo ? `<img src="${p.photo}" alt="">` : initials(p.name)}</div>`

export default class extends Controller {
  static targets = ["list", "search", "address", "profession", "status", "count"]
  static values = { url: String }

  async connect() {
    const res = await fetch(this.urlValue)
    this.people = (await res.json()).people
    this.fill(this.addressTarget, "address")
    this.fill(this.professionTarget, "profession")
    this.render()
  }

  fill(select, key) {
    ;[...new Set(this.people.map(p => p[key]).filter(Boolean))].sort()
      .forEach(v => select.add(new Option(v, v)))
  }

  render() {
    const q = this.searchTarget.value.toLowerCase()
    const { value: address } = this.addressTarget
    const { value: profession } = this.professionTarget
    const { value: status } = this.statusTarget

    const results = this.people.filter(p =>
      p.name.toLowerCase().includes(q) &&
      (!address || p.address === address) &&
      (!profession || p.profession === profession) &&
      (!status || (status === "alive") === !p.dateOfDeath)
    )

   this.listTarget.innerHTML = results.map(p => `
  <a class="card" href="/people/${p.id}">
    ${p.dateOfDeath ? "" : '<span class="living" title="Living"></span>'}
    ${avatar(p)}
    <h3>${p.name}</h3>
    <p class="role">${p.profession || "—"}</p>
    <span class="badge">${p.dob?.slice(0, 4) || "?"} – ${p.dateOfDeath?.slice(0, 4) || "present"}</span>
  </a>`).join("")
  }
}